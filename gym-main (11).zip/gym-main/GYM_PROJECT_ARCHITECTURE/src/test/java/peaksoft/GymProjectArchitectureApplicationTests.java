package peaksoft;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GymProjectArchitectureApplicationTests {

    @Test
    void contextLoads() {
    }

}
