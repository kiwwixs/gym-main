package peaksoft.dto.trainer;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TrainerRequest {

    private String firstName;
    private String lastName;
    private String specialization;


}