package peaksoft.dto.trainer;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class FreeRequest {

    private String userName;
}