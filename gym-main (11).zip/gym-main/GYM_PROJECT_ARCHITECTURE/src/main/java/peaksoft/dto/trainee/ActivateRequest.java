package peaksoft.dto.trainee;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ActivateRequest {

    private String userName;
    private Boolean isActive;

}