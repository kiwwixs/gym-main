package peaksoft.dto.user;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserCheckReq{

    private String userName;
    private String password;

}