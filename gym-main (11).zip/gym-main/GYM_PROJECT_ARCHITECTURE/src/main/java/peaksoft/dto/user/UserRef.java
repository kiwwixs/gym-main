package peaksoft.dto.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRef{

    private String firstName;
    private String lastName;
    private String userName;
    private String password;


}
