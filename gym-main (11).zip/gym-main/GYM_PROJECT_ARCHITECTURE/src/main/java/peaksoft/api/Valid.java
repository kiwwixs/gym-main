package peaksoft.api;


public @interface Valid {
}